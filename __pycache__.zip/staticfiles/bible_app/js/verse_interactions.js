class VerseInteractions {
    constructor() {
        this.initializeCopyButtons();
        this.initializePrintButtons();
    }

    initializeCopyButtons() {
        document.querySelectorAll('.copy-verse').forEach(button => {
            button.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const verseCard = e.target.closest('.verse-card');
                const reference = verseCard.querySelector('.verse-reference').textContent.trim();
                const aramaic = verseCard.querySelector('.aramaic-text').textContent.trim();
                const portuguese = verseCard.querySelector('[lang="pt-BR"]').textContent.trim();
                
                const textToCopy = `${reference}\n\nAramaico:\n${aramaic}\n\nPortuguês:\n${portuguese}`;
                
                try {
                    await navigator.clipboard.writeText(textToCopy);
                    this.showCopyFeedback(button);
                } catch (err) {
                    console.error('Erro ao copiar:', err);
                    alert('Não foi possível copiar o texto. Por favor, tente novamente.');
                }
            });
        });
    }

    showCopyFeedback(button) {
        const icon = button.querySelector('i');
        const originalClass = icon.className;
        
        icon.className = 'bi bi-check-lg';
        button.classList.add('btn-success');
        button.classList.remove('btn-outline-secondary');
        
        setTimeout(() => {
            icon.className = originalClass;
            button.classList.remove('btn-success');
            button.classList.add('btn-outline-secondary');
        }, 2000);
    }

    initializePrintButtons() {
        document.querySelectorAll('.print-verse').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const verseCard = e.target.closest('.verse-card');
                const reference = verseCard.querySelector('.verse-reference').textContent.trim();
                const aramaic = verseCard.querySelector('.aramaic-text').textContent.trim();
                const portuguese = verseCard.querySelector('[lang="pt-BR"]').textContent.trim();
                
                this.openPrintWindow(reference, aramaic, portuguese);
            });
        });
    }

    openPrintWindow(reference, aramaic, portuguese) {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>${reference}</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    @media print {
                        body { padding: 20px; }
                        .hebrew-font {
                            font-family: 'SBL Hebrew', serif;
                            direction: rtl;
                            text-align: right;
                            font-size: 18px;
                        }
                        .verse-content { margin: 20px 0; }
                        .text-section { margin: 15px 0; }
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2 class="mb-4">${reference}</h2>
                    <div class="verse-content">
                        <div class="text-section">
                            <h5>Texto em Aramaico:</h5>
                            <p class="hebrew-font">${aramaic}</p>
                        </div>
                        <div class="text-section">
                            <h5>Tradução em Português:</h5>
                            <p>${portuguese}</p>
                        </div>
                    </div>
                </div>
                <script>
                    window.onload = () => {
                        setTimeout(() => {
                            window.print();
                            window.close();
                        }, 500);
                    };
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new VerseInteractions();
});