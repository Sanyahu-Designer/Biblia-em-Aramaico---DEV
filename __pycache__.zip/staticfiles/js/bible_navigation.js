class BibleNavigation {
    constructor() {
        this.bookSelect = document.getElementById('book-select');
        this.chapterSelect = document.getElementById('chapter-select');
        this.initializeEventListeners();
        this.loadInitialChapters();
    }

    initializeEventListeners() {
        this.bookSelect.addEventListener('change', () => {
            this.loadChapters(this.bookSelect.value);
            this.updateURL();
        });
        
        this.chapterSelect.addEventListener('change', () => {
            this.updateURL();
        });
    }

    async loadChapters(bookId) {
        if (!bookId) {
            this.updateChapterSelect('<option value="">Selecione um Capítulo</option>', true);
            return;
        }
        
        try {
            const response = await fetch(`/get-chapters/?book_id=${bookId}`);
            const chapters = await response.json();
            
            let options = '<option value="">Selecione um Capítulo</option>';
            chapters.forEach(chapter => {
                const selected = chapter.id == selectedChapterId ? 'selected' : '';
                options += `<option value="${chapter.id}" ${selected}>Capítulo ${chapter.number}</option>`;
            });
            
            this.updateChapterSelect(options, false);
        } catch (error) {
            console.error('Erro ao carregar capítulos:', error);
        }
    }

    updateChapterSelect(html, disabled) {
        this.chapterSelect.innerHTML = html;
        this.chapterSelect.disabled = disabled;
    }

    updateURL() {
        const bookId = this.bookSelect.value;
        const chapterId = this.chapterSelect.value;
        if (bookId && chapterId) {
            window.location.href = `/?book=${bookId}&chapter=${chapterId}`;
        }
    }

    loadInitialChapters() {
        if (this.bookSelect.value) {
            this.loadChapters(this.bookSelect.value);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.bibleNavigation = new BibleNavigation();
});