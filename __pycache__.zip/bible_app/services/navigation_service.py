"""Service for handling Bible navigation logic."""
from django.db.models import QuerySet
from ..models import Book, Chapter

class NavigationService:
    @staticmethod
    def get_adjacent_chapters(chapter_id: int) -> dict:
        """Get previous and next chapters for navigation.
        
        Args:
            chapter_id (int): Current chapter ID
            
        Returns:
            dict: Dictionary containing previous and next chapters
        """
        current_chapter = Chapter.objects.select_related('book').get(id=chapter_id)
        
        # Get previous chapter in same book
        previous_chapter = Chapter.objects.filter(
            book=current_chapter.book,
            number__lt=current_chapter.number
        ).order_by('-number').first()
        
        # If no previous chapter in current book, try previous book's last chapter
        if not previous_chapter:
            previous_book = Book.objects.filter(
                order__lt=current_chapter.book.order
            ).order_by('-order').first()
            if previous_book:
                previous_chapter = Chapter.objects.filter(
                    book=previous_book
                ).order_by('-number').first()
        
        # Get next chapter in same book
        next_chapter = Chapter.objects.filter(
            book=current_chapter.book,
            number__gt=current_chapter.number
        ).order_by('number').first()
        
        # If no next chapter in current book, try next book's first chapter
        if not next_chapter:
            next_book = Book.objects.filter(
                order__gt=current_chapter.book.order
            ).order_by('order').first()
            if next_book:
                next_chapter = Chapter.objects.filter(
                    book=next_book
                ).order_by('number').first()
        
        return {
            'previous_chapter': previous_chapter,
            'next_chapter': next_chapter
        }