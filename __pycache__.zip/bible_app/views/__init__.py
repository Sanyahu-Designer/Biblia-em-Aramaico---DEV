from .bible_views import home, get_chapters

__all__ = ['home', 'get_chapters']