"""Main admin configuration file."""
# This file is intentionally empty as all admin configuration
# has been moved to the admin package